<?php require 'getname.php';

require 'functions.php'; ?>